create
    definer = root@localhost procedure AddProduct(IN productNameIn varchar(50), IN productPriceIn float)
BEGIN
    INSERT INTO product (productName, productPrice) VALUES (productNameIn, productPriceIn);
END;

