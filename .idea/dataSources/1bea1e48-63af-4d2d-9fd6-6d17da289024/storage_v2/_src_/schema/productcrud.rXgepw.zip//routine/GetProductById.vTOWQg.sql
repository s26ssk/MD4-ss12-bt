create
    definer = root@localhost procedure GetProductById(IN productCodeIn int)
BEGIN
    SELECT * FROM product WHERE productCode = productCodeIn;
END;

