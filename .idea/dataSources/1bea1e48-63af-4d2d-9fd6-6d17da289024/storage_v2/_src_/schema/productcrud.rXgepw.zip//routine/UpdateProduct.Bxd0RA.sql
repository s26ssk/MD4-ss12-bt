create
    definer = root@localhost procedure UpdateProduct(IN productCodeIn int, IN productNameIn varchar(100),
                                                     IN productPriceIn double, IN categoryIdIn int)
BEGIN
    UPDATE product
    SET productName = productNameIn, productPrice = productPriceIn, categoryId = categoryIdIn
    WHERE productCode = productCodeIn;
END;

