create
    definer = root@localhost procedure AddCategory(IN categoryNameIn varchar(100), IN statusIn bit)
BEGIN
    INSERT INTO category (categoryName, status) VALUES (categoryNameIn, statusIn);
END;

