create
    definer = root@localhost procedure GetAllCategories()
BEGIN
    SELECT * FROM category;
END;

