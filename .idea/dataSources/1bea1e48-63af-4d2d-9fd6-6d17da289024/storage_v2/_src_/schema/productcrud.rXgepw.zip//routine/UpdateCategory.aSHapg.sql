create
    definer = root@localhost procedure UpdateCategory(IN categoryIdIn int, IN categoryNameIn varchar(100), IN statusIn bit)
BEGIN
    UPDATE category
    SET categoryName = categoryNameIn, status = statusIn
    WHERE categoryId = categoryIdIn;
END;

