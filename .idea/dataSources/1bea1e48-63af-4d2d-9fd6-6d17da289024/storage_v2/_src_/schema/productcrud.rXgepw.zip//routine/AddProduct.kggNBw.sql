create
    definer = root@localhost procedure AddProduct(IN productNameIn varchar(100), IN productPriceIn double,
                                                  IN categoryIdIn int)
BEGIN
    INSERT INTO product (productName, productPrice, categoryId) VALUES (productNameIn, productPriceIn, categoryIdIn);
END;

