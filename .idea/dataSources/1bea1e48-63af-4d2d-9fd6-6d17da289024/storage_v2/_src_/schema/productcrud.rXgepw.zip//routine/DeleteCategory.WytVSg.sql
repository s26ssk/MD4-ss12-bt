create
    definer = root@localhost procedure DeleteCategory(IN categoryIdIn int)
BEGIN
    DELETE FROM category WHERE categoryId = categoryIdIn;
END;

