create
    definer = root@localhost procedure DeleteProduct(IN productCodeIn int)
BEGIN
    DELETE FROM product WHERE productCode = productCodeIn;
END;

