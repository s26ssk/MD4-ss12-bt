create
    definer = root@localhost procedure GetCategoryById(IN categoryIdIn int)
BEGIN
    SELECT * FROM category WHERE categoryId = categoryIdIn;
END;

