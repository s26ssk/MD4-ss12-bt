create
    definer = root@localhost procedure UpdateProduct(IN productCodeIn int, IN productNameIn varchar(50),
                                                     IN productPriceIn float)
BEGIN
    UPDATE product SET productName = productNameIn, productPrice = productPriceIn WHERE productCode = productCodeIn;
END;

